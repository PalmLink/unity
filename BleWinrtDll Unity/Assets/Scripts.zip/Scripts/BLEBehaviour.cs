/*using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
using UnityEngine.UI;
using TMPro;
using Random = System.Random;
using static BLE.Impl;
using System.Threading.Tasks;
using Windows.ApplicationModel.Core;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Foundation;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using System.Diagnostics;

*//* Based on: https://learn.microsoft.com/fr-fr/windows/uwp/devices-sensors/gatt-server and https://github.com/marianylund/BleWinrtDll *//*

public class BLEBehaviour : MonoBehaviour
{
    public TMP_Text TextIsScanning, TextTargetDeviceConnection, TextTargetDeviceData, TextDiscoveredDevices;
    public Button ButtonStartScan;

    // Change this to match your device.
    *//*string targetDeviceName = "PalmLink";*//*
    string targetDeviceName = "Arduino";
    string serviceUuid = "{19b10000-e8f2-537e-4f6c-d104768a1214}";
    string charUuid = "{19b10001-e8f2-537e-4f6c-d104768a1214}";
    *//*string[] characteristicUuids = {
        "{19b10001-e8f2-537e-4f6c-d104768a1214}",      // CUUID 1
        //    "{00002a01-0000-1000-8000-00805f9b34fb}",       // CUUID 2
        //   "{00002a57-0000-1000-8000-00805f9b34fb}",       // CUUID 3
    };*/

/* Ble scan code *//*
BLE ble;
BLE.BLEScan scan;
bool isScanning = false, isConnected = false;
string deviceId = null;
IDictionary<string, string> discoveredDevices = new Dictionary<string, string>();
int devicesCount = 0;
byte[] valuesToWrite;

// BLE Threads 
Thread scanningThread, connectionThread, readingThread, writingThread;

*//* Create the GATT service *//*
GattServiceProviderResult result = await GattServiceProvider.CreateAsync(serviceUuid);

*//* if (result.Error == BluetoothError.Success)
 {
     serviceProvider = result.ServiceProvider;
     // 
 }*/

/* Create the characteristics *//*
GattLocalCharacteristicResult characteristicResult = await serviceProvider.Service.CreateCharacteristicAsync(charUuid, WriteParameters, NotifyParameters);
*//* if (characteristicResult.Error != BluetoothError.Success)
 {
     // An error occurred.
     return;
 }*//*
GattLocalCharacteristic Characteristic = characteristicResult.Characteristic;
*//*Characteristic.ReadRequested += ReadCharacteristic_ReadRequested;*/
/*Characteristic.SubscribedClientsChanged += SubscribedClientsChanged;*/

/* *//*
byte[] valueBLE = new byte[] { 0x99 };

var constantParameters = new GattLocalCharacteristicParameters
{
    CharacteristicProperties = (GattCharacteristicProperties.Read),
    StaticValue = valueBLE.AsBuffer(),
    ReadProtectionLevel = GattProtectionLevel.Plain,
};


float timePassed = 0f;

void Start()
{
    ble = new BLE();

    TextTargetDeviceConnection.text = targetDeviceName + " not found.";
    //readingThread = new Thread(ReadBleData);

    GattServiceProviderAdvertisingParameters advParameters = new GattServiceProviderAdvertisingParameters
    {
        IsDiscoverable = true,
        IsConnectable = true
    };
    serviceProvider.StartAdvertising(advParameters);
}

void Update()
{  
    if (isScanning)
    {
        if (discoveredDevices.Count > devicesCount)
        {
            UpdateGuiText("scan");

            devicesCount = discoveredDevices.Count;
        }                
    } else
    {
        if (TextIsScanning.text != "Not scanning.")
        {
            TextIsScanning.color = Color.white;
            TextIsScanning.text = "Not scanning.";
        }
    }

    // The target device was found.
    if (deviceId != null && deviceId != "-1")
    {
        // Target device is connected and GUI knows.
        if (ble.isConnected && isConnected)
        {
            //UpdateGuiText("writeData");
            timePassed += Time.deltaTime;
            if (timePassed > 5f)
            {
                Debug.Log("wants to read ble data");
                timePassed = 0f;
                readingThread = new Thread(ReadBleData);
                readingThread.Start();
            }

        }
        // Target device is connected, but GUI hasn't updated yet.
        else if (ble.isConnected && !isConnected)
        {
            UpdateGuiText("connected");
            isConnected = true;
            // Device was found, but not connected yet. 
        } else if (!isConnected)
        {
            TextTargetDeviceConnection.text = "Found target device:\n" + targetDeviceName;
        } 
    }
}

public void StartScanHandler()
{
    devicesCount = 0;
    isScanning = true;
    discoveredDevices.Clear();
    scanningThread = new Thread(ScanBleDevices);
    scanningThread.Start();
    TextIsScanning.color = new Color(244, 180, 26);
    TextIsScanning.text = "Scanning...";
    TextIsScanning.text +=
        $"Searching for {targetDeviceName} with \nservice {serviceUuid} and \ncharacteristic {characteristicUuids[0]}";
    TextDiscoveredDevices.text = "";
}

void ScanBleDevices()
{
    scan = BLE.ScanDevices();
    Debug.Log("BLE.ScanDevices() started.");
    scan.Found = (_deviceId, deviceName) =>
    {
        if (!discoveredDevices.ContainsKey(_deviceId))
        {
            Debug.Log("found device with name: " + deviceName);
            discoveredDevices.Add(_deviceId, deviceName);
        }

        if (deviceId == null && deviceName == targetDeviceName)
        {
            deviceId = _deviceId;
        }
    };

    scan.Finished = () =>
    {
        isScanning = false;
        Debug.Log("scan finished");
        if (deviceId == null)
            deviceId = "-1";
    };
    while (deviceId == null)
        Thread.Sleep(500);
    scan.Cancel();
    scanningThread = null;
    isScanning = false;

    if (deviceId == "-1")
    {
        Debug.Log($"Scan is finished. {targetDeviceName} was not found.");
        return;
    }
    Debug.Log($"Found {targetDeviceName} device with id {deviceId}.");
    StartConHandler();
}

public void StartConHandler()
{
    connectionThread = new Thread(ConnectBleDevice);
    connectionThread.Start();
}

void ConnectBleDevice()
{
    if (deviceId != null)
    {
        try
        {
            Debug.Log($"Attempting to connect to {targetDeviceName} device with id {deviceId} ...");
            ble.Connect(deviceId,
                serviceUuid,
                characteristicUuids);
        } catch(Exception e)
        {
            Debug.Log("Could not establish connection to device with ID " + deviceId + "\n" + e);
        }
    }
    if (ble.isConnected)
        Debug.Log("Connected to: " + targetDeviceName);
}

void UpdateGuiText(string action)
{
    switch(action) {
        case "scan":
            TextDiscoveredDevices.text = "";
            foreach (KeyValuePair<string, string> entry in discoveredDevices)
            {
                TextDiscoveredDevices.text += "DeviceID: " + entry.Key + "\nDeviceName: " + entry.Value + "\n\n";
                Debug.Log("Added device: " + entry.Key);
            }
            break;
        case "connected":
            TextTargetDeviceConnection.text = "Connected to target device:\n" + targetDeviceName;
            break;
        case "writeData":
            // if (!readingThread.IsAlive)
            // {
            //     readingThread = new Thread(ReadBleData);
            //     readingThread.Start();
            // }
            // if (remoteAngle != lastRemoteAngle)
            // {
            //     TextTargetDeviceData.text = "Remote angle: " + remoteAngle;
            //     lastRemoteAngle = remoteAngle;
            // }
            break;
    }
}

private void OnDestroy()
{
    CleanUp();
}

private void OnApplicationQuit()
{
    CleanUp();
}

// Prevent threading issues and free BLE stack.
// Can cause Unity to freeze and lead
// to errors when omitted.
private void CleanUp()
{
    try
    {
        scan.Cancel();
        ble.Close();
        scanningThread.Abort();
        connectionThread.Abort();
        //readingThread.Abort();
        writingThread.Abort();
    }
    catch (NullReferenceException e)
    {
        Debug.Log("Thread or object never initialized.\n" + e);
    }
}

public void StartWritingHandler()
{
    if (deviceId == "-1" || !isConnected || (writingThread?.IsAlive ?? false))
    {
        Debug.Log("Cannot write yet");
        Debug.Log("device id= " + deviceId);
        Debug.Log("is connected = " + isConnected);
        return;
    }
    Debug.Log("hello");
    byte[] bytes = new byte[] { 0, 1, 2, 3 };
    byte[] bytes = new byte[] { 12 };
    Random random = new Random();
    int start2 = random.Next(0, bytes.Length);
    valuesToWrite = new byte[] { bytes[0] };
    TextTargetDeviceData.text = "Writing some new: " + valuesToWrite[0];

    writingThread = new Thread(WriteBleData);
    writingThread.Start();
}

private void WriteBleData()
{
    bool ok = BLE.WritePackage(deviceId,
        serviceUuid,
        characteristicUuids[0],
        valuesToWrite);

    Debug.Log($"Writing status: {ok}. {BLE.GetError()}");
    writingThread = null;
}

*//*private void ReadBleData(object obj)*//*
    private void ReadBleData()
    {
        *//*byte[] packageReceived = BLE.ReadBytes();
        BLE.Impl.BLEData packageReceived = new BLE.Impl.BLEData();
        BLE.Impl bleImpl;
        Debug.Log("*** Polling data ***");
        bool result = BLE.Impl.PollData(out packageReceived, false);
        Debug.Log("data polled OK *****");
        Debug.Log(result);
        // Convert little Endian.
        // In this example we're interested about an angle
        // value on the first field of our package.
        remoteAngle = packageReceived[0];
        Debug.Log("Angle: " + packageReceived.buf[0]);
        Debug.Log("** data **");
        int n = packageReceived.buf.Length;
        int i = 0;
        string str = "";
        Debug.Log("length = " + n);
        for (i = 0; i < n && i < 10; i++)
        {
            char c = (char)packageReceived.buf[i];
            str += c;
            Debug.Log(c);
            Debug.Log(packageReceived.buf[i]);
        }
        if (str.Length > 0)
        {
            Debug.Log(str);

        }
        Debug.Log(str);
        Debug.Log("***********");
        Thread.Sleep(100);*//*
    }

    *//* Callbacks for respectively reading and writing */

/* This one might not be useful *//*
async void ReadCharacteristic_ReadRequested(GattLocalCharacteristic sender, GattReadRequestedEventArgs args)
{
    var deferral = args.GetDeferral();

    // Our familiar friend - DataWriter.
    var writer = new DataWriter();
    // populate writer w/ some data. 
    // ... 

    var request = await args.GetRequestAsync();
    request.RespondWithValue(writer.DetachBuffer());

    deferral.Complete();
}

async void WriteCharacteristic_WriteRequested(GattLocalCharacteristic sender, GattWriteRequestedEventArgs args)
{
    Debug.Log("The device has written something.");
    var deferral = args.GetDeferral();

    var request = await args.GetRequestAsync();
    var reader = DataReader.FromBuffer(request.Value);
    // Parse data as necessary. 

    if (request.Option == GattWriteOption.WriteWithResponse)
    {
        request.Respond();
    }

    deferral.Complete();
}

*//* Might not be used *//*
async void NotifyValue()
{
    var writer = new DataWriter();
    // Populate writer with data
    // ...

    await notifyCharacteristic.NotifyValueAsync(writer.DetachBuffer());
}


}

*/




using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
using UnityEngine.UI;
using TMPro;
using Random = System.Random;
using static BLE.Impl;
using PimDeWitte.UnityMainThreadDispatcher;

public class BLEBehaviour : MonoBehaviour
{
    public TMP_Text TextIsScanning, TextTargetDeviceConnection, TextTargetDeviceData, TextDiscoveredDevices;
    public Button ButtonStartScan;

    // Change this to match your device.
    /*string targetDeviceName = "PalmLink";*/
    string targetDeviceName = "Arduino";
    string serviceUuid = "{19b10000-e8f2-537e-4f6c-d104768a1214}";
    string[] characteristicUuids = {
        "{19b10001-e8f2-537e-4f6c-d104768a1214}",      // CUUID 1
        //    "{00002a01-0000-1000-8000-00805f9b34fb}",       // CUUID 2
        //   "{00002a57-0000-1000-8000-00805f9b34fb}",       // CUUID 3
    };

    BLE ble;
    BLE.BLEScan scan;
    bool isScanning = false, isConnected = false;
    string deviceId = null;
    IDictionary<string, string> discoveredDevices = new Dictionary<string, string>();
    int devicesCount = 0;
    byte[] valuesToWrite;
    string valuesBLE = "null";
    GameObject BLEMenu ;

    // BLE Threads 
    Thread scanningThread, connectionThread, readingThread, writingThread;

    float timePassed = 0f;

    void Start()
    {
        ble = new BLE();

        TextTargetDeviceConnection.text = targetDeviceName + " not found.";
        //readingThread = new Thread(ReadBleData);
        BLEMenu.SetActive(false);
    }

    void Update()
    {
        if (isScanning)
        {
            if (discoveredDevices.Count > devicesCount)
            {
                UpdateGuiText("scan");

                devicesCount = discoveredDevices.Count;
            }
        }
        else
        {
            if (TextIsScanning.text != "Not scanning.")
            {
                TextIsScanning.color = Color.white;
                TextIsScanning.text = "Not scanning.";
            }
        }

        // The target device was found.
        if (deviceId != null && deviceId != "-1")
        {
            // Target device is connected and GUI knows.
            if (ble.isConnected && isConnected)
            {
                //UpdateGuiText("writeData");
                timePassed += Time.deltaTime;
                if (timePassed > 5f)
                {
                    Debug.Log("wants to read ble data");
                    timePassed = 0f;
                    /*readingThread = new Thread(ReadBleData);
                    readingThread.Start();*/
                    UnityMainThreadDispatcher.Instance().Enqueue(ReadDataEvent());
                    Debug.Log("Values ble = " + valuesBLE);
                }

            }
            // Target device is connected, but GUI hasn't updated yet.
            else if (ble.isConnected && !isConnected)
            {
                UpdateGuiText("connected");
                isConnected = true;
                // Device was found, but not connected yet. 
            }
            else if (!isConnected)
            {
                TextTargetDeviceConnection.text = "Found target device:\n" + targetDeviceName;
            }
        }
    }

    public void StartScanHandler()
    {
        devicesCount = 0;
        isScanning = true;
        discoveredDevices.Clear();
        scanningThread = new Thread(ScanBleDevices);
        scanningThread.Start();
        TextIsScanning.color = new Color(244, 180, 26);
        TextIsScanning.text = "Scanning...";
        TextIsScanning.text +=
            $"Searching for {targetDeviceName} with \nservice {serviceUuid} and \ncharacteristic {characteristicUuids[0]}";
        TextDiscoveredDevices.text = "";
    }

    void ScanBleDevices()
    {
        scan = BLE.ScanDevices();
        Debug.Log("BLE.ScanDevices() started.");
        scan.Found = (_deviceId, deviceName) =>
        {
            if (!discoveredDevices.ContainsKey(_deviceId))
            {
                Debug.Log("found device with name: " + deviceName);
                discoveredDevices.Add(_deviceId, deviceName);
            }

            if (deviceId == null && deviceName == targetDeviceName)
            {
                deviceId = _deviceId;
            }
        };

        scan.Finished = () =>
        {
            isScanning = false;
            Debug.Log("scan finished");
            if (deviceId == null)
                deviceId = "-1";
        };
        while (deviceId == null)
            Thread.Sleep(500);
        scan.Cancel();
        scanningThread = null;
        isScanning = false;

        if (deviceId == "-1")
        {
            Debug.Log($"Scan is finished. {targetDeviceName} was not found.");
            return;
        }
        Debug.Log($"Found {targetDeviceName} device with id {deviceId}.");
        StartConHandler();
    }

    public void StartConHandler()
    {
        connectionThread = new Thread(ConnectBleDevice);
        connectionThread.Start();
    }

    void ConnectBleDevice()
    {
        if (deviceId != null)
        {
            try
            {
                Debug.Log($"Attempting to connect to {targetDeviceName} device with id {deviceId} ...");
                ble.Connect(deviceId,
                    serviceUuid,
                    characteristicUuids);
            }
            catch (Exception e)
            {
                Debug.Log("Could not establish connection to device with ID " + deviceId + "\n" + e);
            }
        }
        if (ble.isConnected)
            Debug.Log("Connected to: " + targetDeviceName);
    }

    void UpdateGuiText(string action)
    {
        switch (action)
        {
            case "scan":
                TextDiscoveredDevices.text = "";
                foreach (KeyValuePair<string, string> entry in discoveredDevices)
                {
                    TextDiscoveredDevices.text += "DeviceID: " + entry.Key + "\nDeviceName: " + entry.Value + "\n\n";
                    Debug.Log("Added device: " + entry.Key);
                }
                break;
            case "connected":
                TextTargetDeviceConnection.text = "Connected to target device:\n" + targetDeviceName;
                break;
            case "writeData":
                // if (!readingThread.IsAlive)
                // {
                //     readingThread = new Thread(ReadBleData);
                //     readingThread.Start();
                // }
                // if (remoteAngle != lastRemoteAngle)
                // {
                //     TextTargetDeviceData.text = "Remote angle: " + remoteAngle;
                //     lastRemoteAngle = remoteAngle;
                // }
                break;
        }
    }

    private void OnDestroy()
    {
        CleanUp();
    }

    private void OnApplicationQuit()
    {
        CleanUp();
    }

    // Prevent threading issues and free BLE stack.
    // Can cause Unity to freeze and lead
    // to errors when omitted.
    private void CleanUp()
    {
        try
        {
            scan.Cancel();
            ble.Close();
            scanningThread.Abort();
            connectionThread.Abort();
            /*readingThread.Abort();
            writingThread.Abort();*/
        }
        catch (NullReferenceException e)
        {
            Debug.Log("Thread or object never initialized.\n" + e);
        }
    }

    public void StartWritingHandler()
    {
        if (deviceId == "-1" || !isConnected || (writingThread?.IsAlive ?? false))
        {
            Debug.Log("Cannot write yet");
            Debug.Log("device id= " + deviceId);
            Debug.Log("is connected = " + isConnected);
            return;
        }
        Debug.Log("hello");
        /*byte[] bytes = new byte[] {0, 1, 2, 3};*/
        byte[] bytes = new byte[] { 12 };
        Random random = new Random();
        int start2 = random.Next(0, bytes.Length);
        valuesToWrite = new byte[] { bytes[0] };
        TextTargetDeviceData.text = "Writing some new: " + valuesToWrite[0];

        writingThread = new Thread(WriteBleData);
        writingThread.Start();
    }

    private void WriteBleData()
    {
        bool ok = BLE.WritePackage(deviceId,
            serviceUuid,
            characteristicUuids[0],
            valuesToWrite);

        Debug.Log($"Writing status: {ok}. {BLE.GetError()}");
        writingThread = null;
    }

    /*private void ReadBleData(object obj)*/
    private void ReadBleData()
    {
        /*byte[] packageReceived = BLE.ReadBytes();*/
        BLE.Impl.BLEData packageReceived = new BLE.Impl.BLEData();
        /*BLE.Impl bleImpl;*/
        /* Debug.Log("*** Polling data ***");*/
        bool result = BLE.Impl.PollData(out packageReceived, false);
        /* Debug.Log("data polled OK *****");
         Debug.Log(result);*/
        // Convert little Endian.
        // In this example we're interested about an angle
        // value on the first field of our package.
        /*remoteAngle = packageReceived[0];*/
        /*Debug.Log("Angle: " + packageReceived.buf[0]);*/
        /*Debug.Log("** data **");*/
        int n = packageReceived.buf.Length;
        int i = 0;
        string str = "";
        /*Debug.Log("length = " + n);*/
        for (i = 0; i < n && i < 10; i++)
        {
            char c = (char)packageReceived.buf[i];
            str += c;
            /*Debug.Log(c);*/
            /*Debug.Log(packageReceived.buf[i]);*/
        }
        if (str.Length > 0)
        {
            Debug.Log(str);
            TextDiscoveredDevices.text = str;
            valuesBLE = String.Copy(str);

        }
        /*Debug.Log(str);*/
        /*Debug.Log("***********");*/
        Thread.Sleep(100);
        /*readingThread = null;*/
    }

    public IEnumerator ReadDataEvent()
    {
        /*Debug.Log("This is executed from the main thread");*/
        BLE.Impl.BLEData packageReceived = new BLE.Impl.BLEData();
        bool result = BLE.Impl.PollData(out packageReceived, false);
        int n = packageReceived.buf.Length;
        int i = 0;
        string str = "";
        /*Debug.Log("length = " + n);*/
        for (i = 0; i < n && i < 10; i++)
        {
            char c = (char)packageReceived.buf[i];
            str += c;
            /*Debug.Log(c);*/
            /*Debug.Log(packageReceived.buf[i]);*/
        }
        if (str.Length > 0)
        {
            Debug.Log(str);
            TextDiscoveredDevices.text = str;
            valuesBLE = String.Copy(str);

        }
        yield return null;
    }

}
